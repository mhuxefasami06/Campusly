/* DANGER: permanently deletes the Campusly database and ALL its data
   (accounts, bookmarks, posted opportunities). Run this only if you want to
   start over, then run campusly.sql again. */
USE master;
GO
IF DB_ID(N'Campusly') IS NOT NULL
BEGIN
    ALTER DATABASE Campusly SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE Campusly;
END
GO
