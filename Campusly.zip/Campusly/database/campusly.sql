/* =====================================================================
   Campusly - SQL Server database (schema + sample data)

   HOW TO RUN
     1. Open this file in SSMS and connect to your server.
     2. Press F5 (Execute). That's it.

   - Creates the database [Campusly] if it does not exist.
   - Safe to re-run: every object is created only if missing and the
     sample data is inserted only when the tables are empty.
   - Needs SQL Server 2017 or newer (uses STRING_SPLIT / STRING_AGG).
   - To wipe everything and start over, run database/reset.sql first.

   TABLES
     Users                 accounts (password stored as a hash, never plain text)
     UserInterests         interest tags chosen by each user
     Categories            Internship, Scholarship, Hackathon, ...
     Opportunities         the listings shown on the site
     Tags / OpportunityTags  many-to-many: tags on each opportunity
     Bookmarks             opportunities a user has saved
     ViewedOpportunities   opportunities a user has opened (for the streak)
   ===================================================================== */

USE master;
GO

IF DB_ID(N'Campusly') IS NULL
    CREATE DATABASE Campusly;
GO

USE Campusly;
GO

/* ---------------------------------------------------------------- Users */
IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
CREATE TABLE dbo.Users (
    UserId        INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Users PRIMARY KEY,
    Name          NVARCHAR(120)     NOT NULL,
    Email         NVARCHAR(160)     NOT NULL CONSTRAINT UQ_Users_Email UNIQUE,
    PasswordHash  NVARCHAR(255)     NOT NULL,
    CreatedAt     DATETIME2(0)      NOT NULL CONSTRAINT DF_Users_CreatedAt DEFAULT SYSUTCDATETIME()
);
GO

IF OBJECT_ID(N'dbo.UserInterests', N'U') IS NULL
CREATE TABLE dbo.UserInterests (
    UserId    INT           NOT NULL,
    Interest  NVARCHAR(60)  NOT NULL,
    CONSTRAINT PK_UserInterests PRIMARY KEY (UserId, Interest),
    CONSTRAINT FK_UserInterests_Users FOREIGN KEY (UserId)
        REFERENCES dbo.Users (UserId) ON DELETE CASCADE
);
GO

/* ----------------------------------------------------------- Categories */
IF OBJECT_ID(N'dbo.Categories', N'U') IS NULL
CREATE TABLE dbo.Categories (
    CategoryId  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Categories PRIMARY KEY,
    Name        NVARCHAR(40)      NOT NULL CONSTRAINT UQ_Categories_Name UNIQUE,
    Slug        NVARCHAR(40)      NOT NULL CONSTRAINT UQ_Categories_Slug UNIQUE   -- page name, e.g. 'internships'
);
GO

/* -------------------------------------------------------- Opportunities */
IF OBJECT_ID(N'dbo.Opportunities', N'U') IS NULL
CREATE TABLE dbo.Opportunities (
    OpportunityId    INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Opportunities PRIMARY KEY,
    CategoryId       INT               NOT NULL,
    Title            NVARCHAR(200)     NOT NULL,
    Organization     NVARCHAR(160)     NOT NULL,
    Location         NVARCHAR(160)     NOT NULL,
    Type             NVARCHAR(20)      NOT NULL,
    Deadline         DATE              NOT NULL,
    Description      NVARCHAR(MAX)     NOT NULL,
    Eligibility      NVARCHAR(300)     NULL,
    Requirements     NVARCHAR(MAX)     NULL,
    Duration         NVARCHAR(120)     NULL,
    Url              NVARCHAR(300)     NULL,
    ContactEmail     NVARCHAR(160)     NULL,
    IsDemo           BIT               NOT NULL CONSTRAINT DF_Opportunities_IsDemo DEFAULT 1,
    CreatedByUserId  INT               NULL,
    CreatedAt        DATETIME2(0)      NOT NULL CONSTRAINT DF_Opportunities_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Opportunities_Type CHECK (Type IN (N'Online', N'In-person', N'Hybrid')),
    CONSTRAINT FK_Opportunities_Categories FOREIGN KEY (CategoryId)
        REFERENCES dbo.Categories (CategoryId),
    -- NO ACTION on purpose: a SET NULL here would give Users -> Bookmarks two
    -- cascade paths, which SQL Server rejects (error 1785).
    CONSTRAINT FK_Opportunities_Users FOREIGN KEY (CreatedByUserId)
        REFERENCES dbo.Users (UserId)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Opportunities_Deadline' AND object_id = OBJECT_ID(N'dbo.Opportunities'))
    CREATE INDEX IX_Opportunities_Deadline ON dbo.Opportunities (Deadline) INCLUDE (CategoryId);
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Opportunities_Category' AND object_id = OBJECT_ID(N'dbo.Opportunities'))
    CREATE INDEX IX_Opportunities_Category ON dbo.Opportunities (CategoryId, Deadline);
GO

/* ------------------------------------------------------- Tags (many:many) */
IF OBJECT_ID(N'dbo.Tags', N'U') IS NULL
CREATE TABLE dbo.Tags (
    TagId  INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Tags PRIMARY KEY,
    Name   NVARCHAR(60)      NOT NULL CONSTRAINT UQ_Tags_Name UNIQUE
);
GO

IF OBJECT_ID(N'dbo.OpportunityTags', N'U') IS NULL
CREATE TABLE dbo.OpportunityTags (
    OpportunityId  INT NOT NULL,
    TagId          INT NOT NULL,
    CONSTRAINT PK_OpportunityTags PRIMARY KEY (OpportunityId, TagId),
    CONSTRAINT FK_OpportunityTags_Opportunities FOREIGN KEY (OpportunityId)
        REFERENCES dbo.Opportunities (OpportunityId) ON DELETE CASCADE,
    CONSTRAINT FK_OpportunityTags_Tags FOREIGN KEY (TagId)
        REFERENCES dbo.Tags (TagId) ON DELETE CASCADE
);
GO

/* ------------------------------------------- Bookmarks and viewed history */
IF OBJECT_ID(N'dbo.Bookmarks', N'U') IS NULL
CREATE TABLE dbo.Bookmarks (
    BookmarkId     INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Bookmarks PRIMARY KEY,
    UserId         INT          NOT NULL,
    OpportunityId  INT          NOT NULL,
    CreatedAt      DATETIME2(0) NOT NULL CONSTRAINT DF_Bookmarks_CreatedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_Bookmarks_User_Opportunity UNIQUE (UserId, OpportunityId),
    CONSTRAINT FK_Bookmarks_Users FOREIGN KEY (UserId)
        REFERENCES dbo.Users (UserId) ON DELETE CASCADE,
    CONSTRAINT FK_Bookmarks_Opportunities FOREIGN KEY (OpportunityId)
        REFERENCES dbo.Opportunities (OpportunityId) ON DELETE CASCADE
);
GO

IF OBJECT_ID(N'dbo.ViewedOpportunities', N'U') IS NULL
CREATE TABLE dbo.ViewedOpportunities (
    ViewId         INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ViewedOpportunities PRIMARY KEY,
    UserId         INT          NOT NULL,
    OpportunityId  INT          NOT NULL,
    ViewedAt       DATETIME2(0) NOT NULL CONSTRAINT DF_ViewedOpportunities_ViewedAt DEFAULT SYSUTCDATETIME(),
    CONSTRAINT UQ_Viewed_User_Opportunity UNIQUE (UserId, OpportunityId),
    CONSTRAINT FK_Viewed_Users FOREIGN KEY (UserId)
        REFERENCES dbo.Users (UserId) ON DELETE CASCADE,
    CONSTRAINT FK_Viewed_Opportunities FOREIGN KEY (OpportunityId)
        REFERENCES dbo.Opportunities (OpportunityId) ON DELETE CASCADE
);
GO

/* ----------------------------------------------------------------- View
   One row per opportunity with its category and a comma-separated tag list.
   Handy for browsing the data in SSMS:  SELECT * FROM dbo.vw_OpportunityDetails;  */
CREATE OR ALTER VIEW dbo.vw_OpportunityDetails
AS
SELECT  o.OpportunityId,
        c.Name          AS Category,
        o.Title,
        o.Organization,
        o.Location,
        o.Type,
        o.Deadline,
        DATEDIFF(DAY, CAST(SYSDATETIME() AS DATE), o.Deadline) AS DaysLeft,
        o.Eligibility,
        o.IsDemo,
        (SELECT STRING_AGG(t.Name, N', ') WITHIN GROUP (ORDER BY t.Name)
           FROM dbo.OpportunityTags ot
           JOIN dbo.Tags t ON t.TagId = ot.TagId
          WHERE ot.OpportunityId = o.OpportunityId) AS Tags
FROM    dbo.Opportunities o
JOIN    dbo.Categories   c ON c.CategoryId = o.CategoryId;
GO

/* ------------------------------------------------------------ Sample data */
IF NOT EXISTS (SELECT 1 FROM dbo.Categories)
    INSERT INTO dbo.Categories (Name, Slug) VALUES
        (N'Internship',   N'internships'),
        (N'Scholarship',  N'scholarships'),
        (N'Hackathon',    N'hackathons'),
        (N'MUN',          N'muns'),
        (N'Competition',  N'competitions'),
        (N'Event',        N'events'),
        (N'Workshop',     N'workshops'),
        (N'Volunteering', N'volunteering');
GO

/* Sample opportunities. Deadlines are stored relative to the day you run this
   script (DaysFromNow), so the listings are open whenever you set it up. */
IF NOT EXISTS (SELECT 1 FROM dbo.Opportunities)
BEGIN
    DECLARE @Today DATE = CAST(SYSDATETIME() AS DATE);

    DECLARE @Seed TABLE (
        SeedNo        INT,
        Category      NVARCHAR(40),
        Title         NVARCHAR(200),
        Organization  NVARCHAR(160),
        Location      NVARCHAR(160),
        Type          NVARCHAR(20),
        DaysFromNow   INT,
        Tags          NVARCHAR(400),
        Description   NVARCHAR(MAX),
        Eligibility   NVARCHAR(300)
    );

    INSERT INTO @Seed (SeedNo, Category, Title, Organization, Location, Type, DaysFromNow, Tags, Description, Eligibility)
    VALUES
        (1, N'Internship', N'Software Engineering Intern', N'Demo Tech Co.', N'Remote', N'Online', 10, N'Software Engineering,Python,Paid', N'Work on real product features with a mentor and ship code in your first month.', N'University students, year 2+'),
        (2, N'Internship', N'Data Science Intern', N'Demo Tech Co.', N'Karachi, Pakistan', N'Hybrid', 21, N'AI,Python,Paid', N'Clean datasets, build dashboards and try ML models on live business questions.', N'Students with basic Python/stats'),
        (3, N'Internship', N'UI/UX Design Intern', N'Demo Tech Co.', N'Remote', N'Online', 28, N'Design,Figma,Unpaid', N'Design and test app flows alongside a small product team.', N'Any student with a portfolio'),
        (4, N'Internship', N'Finance & Analytics Intern', N'Demo Tech Co.', N'Lahore, Pakistan', N'In-person', 15, N'Finance,Excel,Paid', N'Support budgeting, reporting and market research for a growing startup.', N'Business/economics students'),
        (5, N'Internship', N'Startup Growth Intern', N'Demo Tech Co.', N'Remote', N'Online', 47, N'Entrepreneurship,Marketing,Paid', N'Test growth ideas and learn how early-stage startups find customers.', N'Undergraduates'),
        (6, N'Scholarship', N'Global Undergraduate Scholarship', N'Demo Education Fund', N'Multiple Countries', N'In-person', 36, N'Fully Funded,International Relations', N'Covers tuition, housing and travel for outstanding undergraduate applicants.', N'Undergraduate students'),
        (7, N'Scholarship', N'STEM Future Leaders Award', N'Demo Education Fund', N'United Kingdom', N'In-person', 56, N'Software Engineering,AI,Tuition', N'Partial tuition support for women and gender-diverse students in STEM.', N'STEM Master''s applicants'),
        (8, N'Scholarship', N'Community Impact Grant', N'Demo Education Fund', N'Pakistan', N'Online', 31, N'Volunteering,Tuition', N'Financial support for students who lead community service projects.', N'High-school graduates'),
        (9, N'Scholarship', N'Design Excellence Scholarship', N'Demo Education Fund', N'Germany', N'In-person', 87, N'Design,Fully Funded', N'Fully funded design program with monthly stipend.', N'Portfolio required'),
        (10, N'Scholarship', N'Business Leaders Fellowship', N'Demo Education Fund', N'Canada', N'Hybrid', 66, N'Finance,Entrepreneurship,Tuition', N'Tuition waiver plus mentorship from business leaders.', N'Business undergraduates'),
        (11, N'Hackathon', N'Global AI Hackathon 2026', N'Demo Innovation Labs', N'Online', N'Online', 3, N'AI,Software Engineering,Beginner Friendly', N'Build innovative AI solutions and compete with students from around the world.', N'Any student, teams of 2-4'),
        (12, N'Hackathon', N'Campus Green Tech Jam', N'Demo Innovation Labs', N'Karachi, Pakistan', N'In-person', 7, N'Software Engineering,Sustainability', N'A 24-hour build sprint on climate and campus sustainability tools.', N'University students'),
        (13, N'Hackathon', N'FinTech Hack Weekend', N'Demo Innovation Labs', N'Remote', N'Online', 24, N'Finance,Software Engineering', N'Prototype payment and budgeting tools for young people.', N'Teams of 3-5'),
        (14, N'Hackathon', N'Beginner Build Night', N'Demo Innovation Labs', N'Islamabad, Pakistan', N'In-person', 17, N'Beginner Friendly,Design', N'A friendly first hackathon with mentors and starter kits.', N'No experience needed'),
        (15, N'MUN', N'Karachi Youth MUN 2026', N'Demo MUN Society', N'Karachi, Pakistan', N'In-person', 26, N'International Relations,Debate', N'Three-day conference with UNSC, WHO and Crisis committees.', N'Grades 9-12 and university'),
        (16, N'MUN', N'Virtual Global MUN', N'Demo MUN Society', N'Online', N'Online', 13, N'International Relations,Public Speaking', N'Join delegates worldwide from your laptop; beginner committees available.', N'Ages 15+'),
        (17, N'MUN', N'Lahore Model UN Summit', N'Demo MUN Society', N'Lahore, Pakistan', N'In-person', 51, N'International Relations,Debate', N'Debate global policy and network with experienced delegates.', N'University students'),
        (18, N'Competition', N'National Coding Challenge', N'Demo Challenge Board', N'Online', N'Online', 16, N'Software Engineering,Coding', N'Solve algorithmic problems in a timed contest with cash prizes.', N'Undergraduates'),
        (19, N'Competition', N'Business Case Cup', N'Demo Challenge Board', N'Karachi, Pakistan', N'In-person', 34, N'Finance,Entrepreneurship,Business', N'Pitch solutions to a real-style business case to a judging panel.', N'Teams of 3-4'),
        (20, N'Competition', N'Youth Essay Prize', N'Demo Challenge Board', N'Online', N'Online', 61, N'Writing,International Relations', N'Write on the theme ''The World in 2050'' for publication.', N'Ages 16-25'),
        (21, N'Competition', N'Math Olympiad Open', N'Demo Challenge Board', N'Online', N'Online', 41, N'Mathematics,Science', N'Problem-solving contest with rounds for all skill levels.', N'Students under 25'),
        (22, N'Event', N'Student Career Fair', N'Demo Student Network', N'Karachi, Pakistan', N'In-person', 9, N'Career,Networking', N'Meet employers, get CV feedback and explore graduate roles.', N'Open to all students'),
        (23, N'Event', N'Future of AI Student Conference', N'Demo Student Network', N'Online', N'Online', 19, N'AI,Software Engineering', N'Talks and panels on AI careers and research.', N'Free registration'),
        (24, N'Event', N'Startup Networking Mixer', N'Demo Student Network', N'Lahore, Pakistan', N'In-person', 14, N'Entrepreneurship,Networking', N'Meet founders and find teammates for your next project.', N'University students'),
        (25, N'Workshop', N'Python for Beginners', N'Demo Learning Hub', N'Online', N'Online', 6, N'Python,Software Engineering,Beginner Friendly', N'A hands-on 4-week workshop to write your first programs.', N'No experience needed'),
        (26, N'Workshop', N'Design Thinking Lab', N'Demo Learning Hub', N'Islamabad, Pakistan', N'In-person', 23, N'Design,Entrepreneurship', N'Learn to define problems and prototype ideas quickly.', N'Any student'),
        (27, N'Workshop', N'Public Speaking Bootcamp', N'Demo Learning Hub', N'Online', N'Online', 30, N'Public Speaking,Career', N'Practice pitching, storytelling and confident delivery.', N'Ages 16+'),
        (28, N'Workshop', N'Intro to Machine Learning', N'Demo Learning Hub', N'Online', N'Online', 48, N'AI,Python', N'Train your first model with guided notebooks.', N'Basic Python helpful'),
        (29, N'Volunteering', N'Teach a Weekend Class', N'Demo Community Trust', N'Karachi, Pakistan', N'In-person', 22, N'Volunteering,Education', N'Tutor school students in maths and English on weekends.', N'Ages 17+'),
        (30, N'Volunteering', N'Remote Digital Skills Mentor', N'Demo Community Trust', N'Remote', N'Online', 58, N'Volunteering,Software Engineering', N'Mentor learners online on digital literacy topics.', N'University students'),
        (31, N'Volunteering', N'Community Clean-Up Drive', N'Demo Community Trust', N'Lahore, Pakistan', N'In-person', 11, N'Volunteering,Sustainability', N'Join a team cleaning parks and green spaces.', N'Open to all')
    ;

    INSERT INTO dbo.Opportunities
           (CategoryId, Title, Organization, Location, Type, Deadline, Description, Eligibility, IsDemo)
    SELECT  c.CategoryId, s.Title, s.Organization, s.Location, s.Type,
            DATEADD(DAY, s.DaysFromNow, @Today), s.Description, s.Eligibility, 1
    FROM    @Seed s
    JOIN    dbo.Categories c ON c.Name = s.Category
    ORDER BY s.SeedNo;

    INSERT INTO dbo.Tags (Name)
    SELECT DISTINCT LTRIM(RTRIM(x.value))
    FROM   @Seed s
    CROSS APPLY STRING_SPLIT(s.Tags, N',') x
    WHERE  LTRIM(RTRIM(x.value)) <> N''
      AND  NOT EXISTS (SELECT 1 FROM dbo.Tags t WHERE t.Name = LTRIM(RTRIM(x.value)));

    INSERT INTO dbo.OpportunityTags (OpportunityId, TagId)
    SELECT DISTINCT o.OpportunityId, t.TagId
    FROM   @Seed s
    CROSS APPLY STRING_SPLIT(s.Tags, N',') x
    JOIN   dbo.Opportunities o ON o.Title = s.Title
    JOIN   dbo.Tags          t ON t.Name  = LTRIM(RTRIM(x.value));
END
GO

/* Quick check - you should see 8 categories and 31 opportunities */
SELECT (SELECT COUNT(*) FROM dbo.Categories)    AS Categories,
       (SELECT COUNT(*) FROM dbo.Opportunities) AS Opportunities,
       (SELECT COUNT(*) FROM dbo.Tags)          AS Tags,
       (SELECT COUNT(*) FROM dbo.OpportunityTags) AS OpportunityTags;
GO

SELECT * FROM dbo.vw_OpportunityDetails ORDER BY Deadline;
GO
