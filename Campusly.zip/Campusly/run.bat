@echo off
REM Starts Campusly on http://127.0.0.1:5000  (first run installs the Python packages)
cd /d "%~dp0backend"
if not exist .env copy .env.example .env >nul && echo Created backend\.env - open it and check DB_SERVER, then run this again. && notepad .env && exit /b
if not exist venv ( python -m venv venv || (echo Python not found. Install Python 3.10+ from python.org and tick "Add to PATH". & pause & exit /b) )
call venv\Scripts\activate
pip install -q -r requirements.txt || (pause & exit /b)
python app.py
pause
