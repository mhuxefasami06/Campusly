from flask_jwt_extended import get_jwt_identity, verify_jwt_in_request

# The interest tags offered on the sign-up form and the dashboard.
INTERESTS = [
    "Software Engineering", "AI", "Entrepreneurship",
    "Design", "Finance", "International Relations",
]
# What anonymous visitors (and the "match %" on cards) use.
DEFAULT_INTERESTS = INTERESTS[:3]


def current_user_id():
    """Id of the signed-in user, or None. Never raises: a missing, expired or
    invalid token just means 'anonymous'."""
    try:
        verify_jwt_in_request(optional=True)
        identity = get_jwt_identity()
        return int(identity) if identity else None
    except Exception:
        return None


def match_score(opp, interests):
    """Simple, explainable 'match %': a base score plus a bonus per matching tag."""
    overlap = len(set(opp.tags) & set(interests))
    return min(99, 52 + overlap * 20 + (opp.id % 9))
