import os
import re
from datetime import timedelta
from pathlib import Path
from urllib.parse import quote_plus

from dotenv import load_dotenv

# Read backend/.env if it exists (see .env.example).
load_dotenv(Path(__file__).with_name(".env"))


def _detect_driver():
    """Pick the newest installed 'ODBC Driver NN for SQL Server'."""
    try:
        import pyodbc
    except ImportError:
        return "ODBC Driver 17 for SQL Server"

    found = []
    for name in pyodbc.drivers():
        m = re.fullmatch(r"ODBC Driver (\d+) for SQL Server", name)
        if m:
            found.append((int(m.group(1)), name))
    if found:
        return max(found)[1]
    if "SQL Server" in pyodbc.drivers():  # very old built-in Windows driver
        return "SQL Server"
    return "ODBC Driver 17 for SQL Server"


def _database_uri():
    # A full SQLAlchemy URL wins if you set one.
    explicit = os.environ.get("DATABASE_URL")
    if explicit:
        return explicit

    server = os.environ.get("DB_SERVER") or r"localhost\SQLEXPRESS"
    database = os.environ.get("DB_NAME") or "Campusly"
    driver = os.environ.get("DB_DRIVER") or _detect_driver()
    user = os.environ.get("DB_USER", "")
    password = os.environ.get("DB_PASSWORD", "")

    parts = [
        f"DRIVER={{{driver}}}",
        f"SERVER={server}",
        f"DATABASE={database}",
        "TrustServerCertificate=yes",  # local servers use a self-signed cert
    ]
    if user:
        parts += [f"UID={user}", f"PWD={{{password}}}"]
    else:
        parts.append("Trusted_Connection=yes")

    return "mssql+pyodbc:///?odbc_connect=" + quote_plus(";".join(parts))


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-me")

    SQLALCHEMY_DATABASE_URI = _database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True}

    JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", "dev-jwt-secret-change-me")
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(days=7)

    # The app serves the frontend itself, so CORS is only needed if you host
    # the HTML somewhere else. Comma-separated list of allowed origins.
    CORS_ORIGINS = os.environ.get("CORS_ORIGINS", "*")
