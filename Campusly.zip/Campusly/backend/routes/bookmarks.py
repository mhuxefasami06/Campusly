from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy.exc import IntegrityError

from database import db
from models import Bookmark, Opportunity

bookmarks_bp = Blueprint("bookmarks", __name__, url_prefix="/api/bookmarks")


@bookmarks_bp.get("")
@jwt_required()
def list_bookmarks():
    user_id = int(get_jwt_identity())
    marks = Bookmark.query.filter_by(user_id=user_id).order_by(Bookmark.id.desc()).all()
    return jsonify(bookmarks=[m.opportunity.to_dict() for m in marks])


@bookmarks_bp.post("/<int:opp_id>")
@jwt_required()
def add_bookmark(opp_id):
    user_id = int(get_jwt_identity())
    if not db.session.get(Opportunity, opp_id):
        return jsonify(error="Opportunity not found."), 404

    if not Bookmark.query.filter_by(user_id=user_id, opportunity_id=opp_id).first():
        db.session.add(Bookmark(user_id=user_id, opportunity_id=opp_id))
        try:
            db.session.commit()
        except IntegrityError:  # double-click race: already saved, which is fine
            db.session.rollback()

    return jsonify(saved=True), 201


@bookmarks_bp.delete("/<int:opp_id>")
@jwt_required()
def remove_bookmark(opp_id):
    user_id = int(get_jwt_identity())
    Bookmark.query.filter_by(user_id=user_id, opportunity_id=opp_id).delete()
    db.session.commit()
    return jsonify(saved=False)
