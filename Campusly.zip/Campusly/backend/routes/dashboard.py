from datetime import date, datetime, timedelta, timezone

from flask import Blueprint, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from database import db
from models import Bookmark, Opportunity, User, ViewedOpportunity
from utils import match_score

dashboard_bp = Blueprint("dashboard", __name__, url_prefix="/api/dashboard")


def _explored_this_week(user_id):
    week_ago = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=7)
    return ViewedOpportunity.query.filter(
        ViewedOpportunity.user_id == user_id,
        ViewedOpportunity.viewed_at >= week_ago,
    ).count()


@dashboard_bp.get("")
@jwt_required()
def get_dashboard():
    user_id = int(get_jwt_identity())
    user = db.session.get(User, user_id)
    if not user:
        return jsonify(error="Account no longer exists."), 401
    interests = user.interests

    saved = [
        b.opportunity
        for b in Bookmark.query.filter_by(user_id=user_id).order_by(Bookmark.id.desc()).all()
    ]

    open_opps = Opportunity.query.filter(Opportunity.deadline >= date.today()).all()
    upcoming = sorted(open_opps, key=lambda o: (o.deadline, o.id))[:3]
    scored = sorted(
        ((o, match_score(o, interests)) for o in open_opps),
        key=lambda pair: pair[1],
        reverse=True,
    )[:3]

    profile_progress = min(
        100, 20 + len(interests) * 15 + 20 + (15 if saved else 0)
    )  # signed in => name + email are on file, hence the flat +20

    return jsonify(
        saved=[o.to_dict(match=match_score(o, interests)) for o in saved],
        upcoming_deadlines=[o.to_dict(match=match_score(o, interests)) for o in upcoming],
        recommended=[o.to_dict(match=m) for o, m in scored],
        streak={"opportunities_this_week": _explored_this_week(user_id)},
        profile_progress=profile_progress,
        interests=interests,
    )


@dashboard_bp.get("/streak")
@jwt_required()
def get_streak():
    return jsonify(opportunities_this_week=_explored_this_week(int(get_jwt_identity())))
