import re

from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from sqlalchemy.exc import IntegrityError
from werkzeug.security import generate_password_hash, check_password_hash

from database import db
from models import User
from utils import INTERESTS

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _clean_interests(value):
    """Return a de-duplicated list of known interests, or None if invalid."""
    if not isinstance(value, list) or not all(isinstance(i, str) for i in value):
        return None
    return [i for i in dict.fromkeys(value) if i in INTERESTS]


@auth_bp.post("/signup")
def signup():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name") or "").strip()
    email = str(data.get("email") or "").strip().lower()
    password = str(data.get("password") or "")

    if not name or len(name) > 120:
        return jsonify(error="Please enter your name (up to 120 characters)."), 400
    if not EMAIL_RE.match(email) or len(email) > 160:
        return jsonify(error="Please enter a valid email address."), 400
    if len(password) < 6:
        return jsonify(error="Your password must be at least 6 characters."), 400

    interests = _clean_interests(data.get("interests", []))
    if interests is None:
        return jsonify(error="'interests' must be a list of strings."), 400

    if User.query.filter_by(email=email).first():
        return jsonify(error="An account with that email already exists."), 409

    user = User(name=name, email=email, password_hash=generate_password_hash(password))
    user.set_interests(interests)
    db.session.add(user)
    try:
        db.session.commit()
    except IntegrityError:  # two sign-ups with the same email at the same moment
        db.session.rollback()
        return jsonify(error="An account with that email already exists."), 409

    token = create_access_token(identity=str(user.id))
    return jsonify(token=token, user=user.to_dict()), 201


@auth_bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email = str(data.get("email") or "").strip().lower()
    password = str(data.get("password") or "")

    user = User.query.filter_by(email=email).first()
    if not user or not check_password_hash(user.password_hash, password):
        return jsonify(error="Incorrect email or password."), 401

    token = create_access_token(identity=str(user.id))
    return jsonify(token=token, user=user.to_dict())


@auth_bp.get("/me")
@jwt_required()
def me():
    user = db.session.get(User, int(get_jwt_identity()))
    if not user:
        return jsonify(error="Account no longer exists."), 401
    return jsonify(user=user.to_dict())


@auth_bp.put("/interests")
@jwt_required()
def update_interests():
    user = db.session.get(User, int(get_jwt_identity()))
    if not user:
        return jsonify(error="Account no longer exists."), 401

    data = request.get_json(silent=True) or {}
    interests = _clean_interests(data.get("interests"))
    if interests is None:
        return jsonify(error="'interests' must be a list of strings."), 400

    user.set_interests(interests)
    db.session.commit()
    return jsonify(user=user.to_dict())
