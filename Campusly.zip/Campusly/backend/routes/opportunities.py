from datetime import date, timedelta
from urllib.parse import urlparse

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from database import db
from models import Category, Opportunity, Tag, User, ViewedOpportunity
from utils import DEFAULT_INTERESTS, current_user_id, match_score

opportunities_bp = Blueprint("opportunities", __name__, url_prefix="/api")

TYPES = ("Online", "In-person", "Hybrid")


def _viewer_interests(user_id):
    """Interests used to compute the 'match %': the signed-in user's, or the
    defaults for anonymous visitors."""
    if user_id:
        user = db.session.get(User, user_id)
        if user:
            return user.interests
    return DEFAULT_INTERESTS


def _open():
    """Opportunities whose deadline hasn't passed yet."""
    return Opportunity.query.filter(Opportunity.deadline >= date.today())


@opportunities_bp.get("/categories")
def list_categories():
    counts = dict(
        db.session.query(Opportunity.category_id, db.func.count(Opportunity.id))
        .filter(Opportunity.deadline >= date.today())
        .group_by(Opportunity.category_id)
        .all()
    )
    cats = Category.query.order_by(Category.id).all()
    return jsonify(
        categories=[{"name": c.name, "slug": c.slug, "open": counts.get(c.id, 0)} for c in cats]
    )


@opportunities_bp.get("/opportunities")
def list_opportunities():
    """Query params: category, location, type (Online/In-person/Hybrid), tag,
    q (every word must match title/description/organization/location/category/tag),
    deadline_within (days), sort (r recommended, n newest, d deadline soon,
    a recently added - user-posted first)."""
    q = _open()
    args = request.args

    if args.get("category"):
        q = q.filter(Opportunity.category.has(Category.name == args["category"]))
    if args.get("location"):
        q = q.filter(Opportunity.location == args["location"])
    if args.get("type"):
        q = q.filter(Opportunity.type == args["type"])
    if args.get("tag"):
        q = q.filter(Opportunity.tag_rows.any(Tag.name == args["tag"]))

    within = args.get("deadline_within", type=int)
    if within and within > 0:
        q = q.filter(Opportunity.deadline <= date.today() + timedelta(days=within))

    for word in args.get("q", "").split():
        q = q.filter(
            db.or_(
                Opportunity.title.icontains(word, autoescape=True),
                Opportunity.description.icontains(word, autoescape=True),
                Opportunity.organization.icontains(word, autoescape=True),
                Opportunity.location.icontains(word, autoescape=True),
                Opportunity.category.has(Category.name.icontains(word, autoescape=True)),
                Opportunity.tag_rows.any(Tag.name.icontains(word, autoescape=True)),
            )
        )

    sort = args.get("sort", "r")
    if sort == "d":
        q = q.order_by(Opportunity.deadline.asc(), Opportunity.id.asc())
    elif sort == "a":
        q = q.order_by(Opportunity.is_demo.asc(), Opportunity.id.desc())
    else:  # "n" newest, and the base order for "r"
        q = q.order_by(Opportunity.id.desc())

    interests = _viewer_interests(current_user_id())
    rows = q.all()
    scored = [(o, match_score(o, interests)) for o in rows]
    if sort not in ("d", "n", "a"):  # recommended = best match first (stable)
        scored.sort(key=lambda pair: pair[1], reverse=True)

    return jsonify(
        count=len(scored),
        opportunities=[o.to_dict(match=m) for o, m in scored],
    )


@opportunities_bp.get("/opportunities/<int:opp_id>")
def get_opportunity(opp_id):
    opp = db.session.get(Opportunity, opp_id)
    if not opp:
        return jsonify(error="Opportunity not found."), 404

    # Log a view for the streak when signed in; anonymous browsing still works.
    user_id = current_user_id()
    if user_id:
        seen = ViewedOpportunity.query.filter_by(user_id=user_id, opportunity_id=opp_id).first()
        if not seen:
            db.session.add(ViewedOpportunity(user_id=user_id, opportunity_id=opp_id))
            db.session.commit()

    match = match_score(opp, _viewer_interests(user_id))
    return jsonify(opportunity=opp.to_dict(match=match))


def _text(data, key, max_len, required=False):
    """Read a trimmed string field. Raises ValueError with a friendly message."""
    value = data.get(key)
    value = value.strip() if isinstance(value, str) else ""
    if required and not value:
        raise ValueError(f"'{key}' is required.")
    if len(value) > max_len:
        raise ValueError(f"'{key}' must be at most {max_len} characters.")
    return value or None


@opportunities_bp.post("/opportunities")
@jwt_required(optional=True)
def create_opportunity():
    """Backs the 'Post Opportunity' form. Signing in is optional."""
    data = request.get_json(silent=True) or {}

    try:
        title = _text(data, "title", 200, required=True)
        organization = _text(data, "organization", 160, required=True)
        location = _text(data, "location", 160, required=True)
        description = _text(data, "description", 8000, required=True)
        eligibility = _text(data, "eligibility", 300)
        url = _text(data, "url", 300)
        contact_email = _text(data, "contact_email", 160)
        category_name = _text(data, "category", 40, required=True)
        deadline_raw = _text(data, "deadline", 10, required=True)
    except ValueError as e:
        return jsonify(error=str(e)), 400

    category = Category.query.filter_by(name=category_name).first()
    if not category:
        names = [c.name for c in Category.query.order_by(Category.id)]
        return jsonify(error=f"category must be one of {names}"), 400

    try:
        deadline = date.fromisoformat(deadline_raw)
    except ValueError:
        return jsonify(error="deadline must be in YYYY-MM-DD format."), 400
    if deadline < date.today():
        return jsonify(error="The deadline can't be in the past."), 400

    # Only http(s) links: these are shown to other visitors as "Apply" links,
    # so never store javascript: or other schemes.
    if url and urlparse(url).scheme not in ("http", "https"):
        return jsonify(error="url must start with http:// or https://"), 400

    type_ = data.get("type")
    if type_ not in TYPES:
        type_ = "Online" if any(w in location.lower() for w in ("online", "remote")) else "In-person"

    opp = Opportunity(
        category_id=category.id,
        title=title,
        organization=organization,
        location=location,
        type=type_,
        deadline=deadline,
        description=description,
        eligibility=eligibility,
        url=url,
        contact_email=contact_email,
        is_demo=False,
        created_by_id=int(get_jwt_identity()) if get_jwt_identity() else None,
    )
    opp.tag_rows = [_get_or_create_tag(category.name)]
    db.session.add(opp)
    db.session.commit()

    return jsonify(opportunity=opp.to_dict()), 201


def _get_or_create_tag(name):
    tag = Tag.query.filter_by(name=name).first()
    if not tag:
        tag = Tag(name=name)
        db.session.add(tag)
    return tag
