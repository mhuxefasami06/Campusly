import sys
from pathlib import Path

from flask import Flask, abort, jsonify, send_from_directory
from flask_cors import CORS
from flask_jwt_extended import JWTManager

from config import Config
from database import db

# The HTML/CSS/JS live one folder up from backend/.
FRONTEND_DIR = Path(__file__).resolve().parent.parent
PAGES = {
    "index", "internships", "scholarships", "hackathons", "muns",
    "competitions", "events", "workshops", "volunteering", "dashboard",
}


def create_app(config_class=Config):
    # static_folder=None: we serve the frontend through the explicit routes
    # below, so that backend/ (code, .env with passwords) is never reachable.
    app = Flask(__name__, static_folder=None)
    app.config.from_object(config_class)

    db.init_app(app)
    JWTManager(app)
    origins = app.config["CORS_ORIGINS"]
    CORS(app, resources={r"/api/*": {"origins": origins.split(",") if origins != "*" else "*"}})

    from routes.auth import auth_bp
    from routes.opportunities import opportunities_bp
    from routes.bookmarks import bookmarks_bp
    from routes.dashboard import dashboard_bp

    for bp in (auth_bp, opportunities_bp, bookmarks_bp, dashboard_bp):
        app.register_blueprint(bp)

    @app.get("/api/health")
    def health():
        db.session.execute(db.text("SELECT 1"))
        return jsonify(status="ok", database="connected")

    # ---- frontend ----------------------------------------------------
    @app.get("/")
    def home():
        return send_from_directory(FRONTEND_DIR, "index.html")

    @app.get("/<page>.html")
    def page(page):
        if page not in PAGES:
            abort(404)
        return send_from_directory(FRONTEND_DIR, f"{page}.html")

    @app.get("/css/<path:filename>")
    def css(filename):
        return send_from_directory(FRONTEND_DIR / "css", filename)

    @app.get("/js/<path:filename>")
    def js(filename):
        return send_from_directory(FRONTEND_DIR / "js", filename)

    # ---- errors ------------------------------------------------------
    @app.errorhandler(404)
    def not_found(e):
        return jsonify(error="Not found."), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify(error="Something went wrong on our end."), 500

    return app


app = create_app()


def _check_database():
    """Fail early with a readable message if SQL Server can't be reached."""
    try:
        with app.app_context():
            db.session.execute(db.text("SELECT COUNT(*) FROM dbo.Opportunities"))
    except Exception as exc:  # noqa: BLE001
        print("\n*** Could not use the Campusly database ***", file=sys.stderr)
        print(f"{type(exc).__name__}: {str(exc).splitlines()[0][:300]}\n", file=sys.stderr)
        print(
            "Checklist:\n"
            "  1. Did you run database/campusly.sql in SSMS?\n"
            "  2. Is DB_SERVER in backend/.env exactly the server name SSMS connects to?\n"
            "  3. Is the SQL Server service running (and, for SQL logins, DB_USER/DB_PASSWORD set)?\n"
            "  4. Is a Microsoft ODBC Driver for SQL Server installed? (see README)\n",
            file=sys.stderr,
        )
        sys.exit(1)


if __name__ == "__main__":
    _check_database()
    print("\nCampusly is running -> http://127.0.0.1:5000\n")
    app.run(host="127.0.0.1", port=5000, debug=False)
