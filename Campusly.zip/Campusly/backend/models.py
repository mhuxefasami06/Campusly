"""SQLAlchemy models. They map onto the tables created by database/campusly.sql
(the SQL script owns the schema; the app never creates or alters tables)."""

from database import db

# Many-to-many link between opportunities and tags.
opportunity_tags = db.Table(
    "OpportunityTags",
    db.Column("OpportunityId", db.Integer, db.ForeignKey("Opportunities.OpportunityId"), primary_key=True),
    db.Column("TagId", db.Integer, db.ForeignKey("Tags.TagId"), primary_key=True),
)


class User(db.Model):
    __tablename__ = "Users"

    id = db.Column("UserId", db.Integer, primary_key=True)
    name = db.Column("Name", db.Unicode(120), nullable=False)
    email = db.Column("Email", db.Unicode(160), unique=True, nullable=False)
    password_hash = db.Column("PasswordHash", db.Unicode(255), nullable=False)
    created_at = db.Column("CreatedAt", db.DateTime, server_default=db.text("SYSUTCDATETIME()"))

    interest_rows = db.relationship(
        "UserInterest", cascade="all, delete-orphan", lazy="selectin"
    )

    @property
    def interests(self):
        return sorted(r.interest for r in self.interest_rows)

    def set_interests(self, names):
        wanted = list(dict.fromkeys(names))
        for row in list(self.interest_rows):
            if row.interest not in wanted:
                self.interest_rows.remove(row)
        have = {r.interest for r in self.interest_rows}
        for name in wanted:
            if name not in have:
                self.interest_rows.append(UserInterest(interest=name))

    def to_dict(self):
        return {"id": self.id, "name": self.name, "email": self.email, "interests": self.interests}


class UserInterest(db.Model):
    __tablename__ = "UserInterests"

    user_id = db.Column("UserId", db.Integer, db.ForeignKey("Users.UserId"), primary_key=True)
    interest = db.Column("Interest", db.Unicode(60), primary_key=True)


class Category(db.Model):
    __tablename__ = "Categories"

    id = db.Column("CategoryId", db.Integer, primary_key=True)
    name = db.Column("Name", db.Unicode(40), unique=True, nullable=False)
    slug = db.Column("Slug", db.Unicode(40), unique=True, nullable=False)


class Tag(db.Model):
    __tablename__ = "Tags"

    id = db.Column("TagId", db.Integer, primary_key=True)
    name = db.Column("Name", db.Unicode(60), unique=True, nullable=False)


class Opportunity(db.Model):
    __tablename__ = "Opportunities"

    id = db.Column("OpportunityId", db.Integer, primary_key=True)
    category_id = db.Column("CategoryId", db.Integer, db.ForeignKey("Categories.CategoryId"), nullable=False)
    title = db.Column("Title", db.Unicode(200), nullable=False)
    organization = db.Column("Organization", db.Unicode(160), nullable=False)
    location = db.Column("Location", db.Unicode(160), nullable=False)
    type = db.Column("Type", db.Unicode(20), nullable=False)  # Online / In-person / Hybrid
    deadline = db.Column("Deadline", db.Date, nullable=False)
    description = db.Column("Description", db.UnicodeText, nullable=False)
    eligibility = db.Column("Eligibility", db.Unicode(300))
    requirements = db.Column("Requirements", db.UnicodeText)
    duration = db.Column("Duration", db.Unicode(120))
    url = db.Column("Url", db.Unicode(300))
    contact_email = db.Column("ContactEmail", db.Unicode(160))
    is_demo = db.Column("IsDemo", db.Boolean, nullable=False, server_default=db.text("1"))
    created_by_id = db.Column("CreatedByUserId", db.Integer, db.ForeignKey("Users.UserId"))
    created_at = db.Column("CreatedAt", db.DateTime, server_default=db.text("SYSUTCDATETIME()"))

    category = db.relationship("Category", lazy="joined")
    tag_rows = db.relationship("Tag", secondary=opportunity_tags, lazy="selectin", order_by="Tag.name")

    @property
    def tags(self):
        return [t.name for t in self.tag_rows]

    def to_dict(self, match=None):
        data = {
            "id": self.id,
            "category": self.category.name,
            "title": self.title,
            "organization": self.organization,
            "location": self.location,
            "type": self.type,
            "deadline": self.deadline.isoformat(),
            "description": self.description,
            "eligibility": self.eligibility,
            "requirements": self.requirements,
            "duration": self.duration,
            "tags": self.tags,
            "url": self.url,
            "contact_email": self.contact_email,
            "demo": bool(self.is_demo),
        }
        if match is not None:
            data["match"] = match
        return data


class Bookmark(db.Model):
    __tablename__ = "Bookmarks"

    id = db.Column("BookmarkId", db.Integer, primary_key=True)
    user_id = db.Column("UserId", db.Integer, db.ForeignKey("Users.UserId"), nullable=False)
    opportunity_id = db.Column("OpportunityId", db.Integer, db.ForeignKey("Opportunities.OpportunityId"), nullable=False)
    created_at = db.Column("CreatedAt", db.DateTime, server_default=db.text("SYSUTCDATETIME()"))

    opportunity = db.relationship("Opportunity", lazy="joined")


class ViewedOpportunity(db.Model):
    """Which opportunities a user has opened (drives the 'explored' streak)."""

    __tablename__ = "ViewedOpportunities"

    id = db.Column("ViewId", db.Integer, primary_key=True)
    user_id = db.Column("UserId", db.Integer, db.ForeignKey("Users.UserId"), nullable=False)
    opportunity_id = db.Column("OpportunityId", db.Integer, db.ForeignKey("Opportunities.OpportunityId"), nullable=False)
    viewed_at = db.Column("ViewedAt", db.DateTime, server_default=db.text("SYSUTCDATETIME()"))
