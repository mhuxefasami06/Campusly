#!/usr/bin/env bash
# Starts Campusly on http://127.0.0.1:5000
set -e
cd "$(dirname "$0")/backend"
[ -f .env ] || { cp .env.example .env; echo "Created backend/.env - edit DB_SERVER/DB_USER/DB_PASSWORD, then run again."; exit 1; }
[ -d venv ] || python3 -m venv venv
source venv/bin/activate
pip install -q -r requirements.txt
python app.py
