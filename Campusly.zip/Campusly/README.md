# Campusly (Flask + SQL Server)

One app: the Flask backend serves the website **and** the API, and stores everything in SQL Server.

```
Campusly/
├── database/campusly.sql   <- run in SSMS (schema + sample data)
├── database/reset.sql      <- optional: deletes the database to start over
├── backend/                <- Flask API (app.py) + .env.example
├── *.html, css/, js/       <- the website (served by Flask)
├── run.bat / run.sh        <- one-click start
```

## 1. Create the database (SSMS)
1. Open SSMS, connect to your server, note the **Server name** (e.g. `localhost\SQLEXPRESS`).
2. File > Open > `database/campusly.sql`, press **F5**.
3. The last two result grids should show 8 categories, 31 opportunities.

Needs SQL Server 2017 or newer. Sample deadlines are set relative to the day you run the script.

## 2. Install prerequisites (once)
- **Python 3.10+** (tick "Add to PATH").
- **Microsoft ODBC Driver 17 or 18 for SQL Server** (free download from Microsoft). Without it the app can't connect.

## 3. Run
Windows: double-click **run.bat**. First run creates `backend\.env` and opens it:
set `DB_SERVER` to your SSMS server name. Leave `DB_USER` empty for Windows login, or fill
`DB_USER`/`DB_PASSWORD` for SQL login (e.g. `sa`). Then run `run.bat` again.

Mac/Linux: `./run.sh`.

Open **http://127.0.0.1:5000**. Sign up, save opportunities, post one, check the dashboard.
Check the connection at http://127.0.0.1:5000/api/health.

## Troubleshooting
- *Login failed / cannot open server*: DB_SERVER must match SSMS exactly; make sure the SQL Server service is running. For SQL logins, enable "SQL Server and Windows Authentication" and TCP/IP in SQL Server Configuration Manager.
- *Data source name not found*: install the ODBC driver, or set `DB_DRIVER` in `.env`.
- Browse data in SSMS: `SELECT * FROM dbo.vw_OpportunityDetails;`

## Notes
- Passwords are hashed; set real `SECRET_KEY`/`JWT_SECRET_KEY` in `.env` before deploying.
- The SQL script owns the schema; the app never creates or alters tables.
- Posted opportunity URLs must be http(s).
