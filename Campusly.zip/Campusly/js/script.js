/* Campusly UI logic. All data comes from the Flask/SQL Server API (see backend/).
   If you host the HTML on a different origin than the API, set
   window.CAMPUSLY_API = "http://your-server:5000" before this script loads. */
(()=>{
const API=(window.CAMPUSLY_API||"")+"/api";
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const store={get:(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},set:(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{}},del:k=>{try{localStorage.removeItem(k)}catch{}}};
const CATS={Internship:["💼","internships"],Scholarship:["🎓","scholarships"],Hackathon:["💻","hackathons"],MUN:["🌎","muns"],Competition:["🏆","competitions"],Event:["🎤","events"],Workshop:["🧠","workshops"],Volunteering:["🤝","volunteering"]};
const INTERESTS=["Software Engineering","AI","Entrepreneurship","Design","Finance","International Relations"];
const fmt=d=>new Date(d).toLocaleDateString("en",{month:"short",day:"numeric",year:"numeric",timeZone:"UTC"});
const days=d=>Math.ceil((new Date(d)-Date.now())/864e5);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const safeUrl=u=>/^https?:\/\//i.test(u||"")?u:"";

/* ---------- session + API ---------- */
let TOKEN=store.get("cs_token",null),USER=store.get("cs_user",null),SAVED=new Set();
if(!USER||typeof USER!=="object")USER=null;
if(!TOKEN)USER=null;
const clearSession=()=>{TOKEN=null;USER=null;SAVED=new Set();store.del("cs_token");store.del("cs_user")};
async function api(path,{method="GET",body}={}){
 const headers={};if(body)headers["Content-Type"]="application/json";if(TOKEN)headers.Authorization="Bearer "+TOKEN;
 let res;try{res=await fetch(API+path,{method,headers,body:body?JSON.stringify(body):undefined})}
 catch{throw new Error("Can't reach the Campusly server. Is it running?")}
 const data=await res.json().catch(()=>({}));
 if(!res.ok){
  if(TOKEN&&(res.status===401||res.status===422)&&!path.startsWith("/auth/login")){clearSession();user()} // expired/invalid token
  throw new Error(data.error||data.msg||"Something went wrong. Please try again.");
 }
 return data;
}
const toast=msg=>{const t=document.createElement("div");t.className="toast";t.setAttribute("role","status");t.textContent=msg;document.body.append(t);setTimeout(()=>t.remove(),3500)};
const loadSaved=async()=>{if(!USER)return;try{SAVED=new Set((await api("/bookmarks")).bookmarks.map(b=>b.id))}catch{}};

/* ---------- shared layout ---------- */
const links=[["index","Home"],["internships","Internships"],["scholarships","Scholarships"],["hackathons","Hackathons"],["muns","MUNs"],["competitions","Competitions"],["events","Events"]];
const here=(location.pathname.split("/").pop()||"index.html").replace(".html","")||"index";
const li=([p,t])=>`<a href="${p}.html"${p===here?' aria-current="page"':""}>${t}</a>`;
document.body.insertAdjacentHTML("afterbegin",`<a class="skip" href="#main">Skip to content</a>
<header class="nav"><div class="wrap navin"><a class="logo" href="index.html"><svg width="28" height="28" viewBox="0 0 32 32" aria-hidden="true"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#2563eb"/><stop offset="1" stop-color="#7c3aed"/></linearGradient></defs><rect width="32" height="32" rx="9" fill="url(#lg)"/><path d="M9 20l7-10 7 10" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round"/></svg>Campusly</a>
<button class="burger" aria-label="Menu" aria-expanded="false" aria-controls="menu">☰</button>
<nav id="menu" aria-label="Main">${links.map(li).join("")}<details class="more"><summary>More</summary><div>${li(["workshops","Workshops"])}${li(["volunteering","Volunteering"])}${li(["dashboard","My Dashboard"])}</div></details></nav>
<div class="navact"><button class="icon" id="sIcon" aria-label="Search">🔍</button><button class="btn ghost" data-open="post">Post Opportunity</button><button class="btn" id="signBtn" data-open="sign">Sign In</button></div></div></header>`);
document.body.insertAdjacentHTML("beforeend",`<footer class="foot"><div class="wrap fgrid"><div><a class="logo" href="index.html">Campusly</a><p>Helping students discover opportunities and build their future.</p><p class="soc"><a href="https://instagram.com" rel="noopener" target="_blank">Instagram</a><a href="https://linkedin.com" rel="noopener" target="_blank">LinkedIn</a><a href="https://x.com" rel="noopener" target="_blank">X</a><a href="https://discord.com" rel="noopener" target="_blank">Discord</a></p></div>
<div><b>Company</b><button data-info="About">About</button><button data-info="Contact">Contact</button><button data-info="Privacy">Privacy</button><button data-info="Terms">Terms</button></div>
<div><b>Explore</b><a href="internships.html">Internships</a><a href="scholarships.html">Scholarships</a><a href="hackathons.html">Hackathons</a><a href="muns.html">MUNs</a></div></div><p class="copy">© 2026 Campusly. All rights reserved.</p></footer>
<dialog id="dlg"><button class="x" data-close aria-label="Close">✕</button><div id="dlgBody"></div></dialog>`);
const dlg=$("#dlg"),show=h=>{$("#dlgBody").innerHTML=h;dlg.showModal()};
$(".burger").onclick=e=>{const o=$("#menu").classList.toggle("open");e.target.setAttribute("aria-expanded",o)};
if(here==="dashboard")$("#sIcon").hidden=false;
function user(){$("#signBtn").textContent=USER?USER.name.split(" ")[0]:"Sign In"}

/* ---------- cards ---------- */
const card=o=>{const s=SAVED.has(o.id);return`<article class="card"><div class="row"><span class="badge">${CATS[o.category]?.[0]||"⭐"} ${esc(o.category)}</span><span class="match">${o.match??""}${o.match!=null?"% match":""}</span></div><h3>${esc(o.title)}</h3><p class="org">${esc(o.organization)}${o.demo?" <em>Demo Opportunity</em>":""}</p><p class="meta">${o.type==="Online"?"🌎":"📍"} ${esc(o.location)} &nbsp; ⏰ ${fmt(o.deadline)}</p><p>${esc(o.description)}</p>${o.eligibility?`<p class="elig"><b>Eligibility:</b> ${esc(o.eligibility)}</p>`:""}<div class="row"><button class="btn ghost" data-save="${o.id}" aria-pressed="${s}">${s?"❤️ Saved":"♡ Save"}</button><button class="btn" data-view="${o.id}">View Details →</button></div></article>`};
const grid=(el,list,empty)=>{el.innerHTML=list.length?list.map(card).join(""):`<p class="empty">${empty||"No opportunities found. Try changing your search or filters."}</p>`};
const gridError=(el,err)=>{el.innerHTML=`<p class="empty">⚠️ ${esc(err.message)}</p>`};
const applyLink=o=>{
 const u=safeUrl(o.url);
 if(u)return`<a class="btn" href="${esc(u)}" target="_blank" rel="noopener">Apply Now →</a>`;
 if(o.demo)return`<a class="btn" href="https://example.com/apply/${o.id}" target="_blank" rel="noopener">Apply Now →</a>`;
 if(o.contact_email)return`<a class="btn" href="mailto:${esc(o.contact_email)}">Contact organizer →</a>`;
 return"";
};
const detail=o=>{const s=SAVED.has(o.id);return`<span class="badge">${CATS[o.category]?.[0]||"⭐"} ${esc(o.category)}</span><h2>${esc(o.title)}</h2><p class="org">${esc(o.organization)}${o.demo?" <em>Demo Opportunity</em>":""}</p><p>${esc(o.description)}</p><dl><dt>Location</dt><dd>${esc(o.location)} (${esc(o.type)})</dd><dt>Deadline</dt><dd>${fmt(o.deadline)} (${Math.max(0,days(o.deadline))} days left)</dd>${o.eligibility?`<dt>Eligibility</dt><dd>${esc(o.eligibility)}</dd>`:""}<dt>Requirements</dt><dd>${o.requirements?esc(o.requirements):"CV or short profile, a brief statement of interest."}</dd><dt>Duration</dt><dd>${esc(o.duration||"Varies by programme")}</dd><dt>Application process</dt><dd>Submit the online form, then shortlisted applicants are contacted by email.</dd><dt>Important dates</dt><dd>Applications close ${fmt(o.deadline)}; results about 3 weeks later.</dd></dl><p>${o.tags.map(t=>`<span class="tag">${esc(t)}</span>`).join("")}</p><div class="row"><button class="btn ghost" data-save="${o.id}" aria-pressed="${s}">${s?"❤️ Saved":"♡ Save"}</button>${applyLink(o)}</div>${o.demo?'<p class="note">Demo data: this link is a placeholder.</p>':""}`};

/* ---------- global click handling ---------- */
document.addEventListener("click",async e=>{
 const t=e.target.closest("[data-save],[data-view],[data-open],[data-info],[data-close],#sIcon");if(!t)return;
 if(t.dataset.save){
  if(!USER){signIn("Sign in to save opportunities.");return}
  const id=+t.dataset.save,on=!SAVED.has(id);
  try{await api("/bookmarks/"+id,{method:on?"POST":"DELETE"})}catch(err){toast(err.message);return}
  on?SAVED.add(id):SAVED.delete(id);
  $$(`[data-save="${id}"]`).forEach(b=>{b.setAttribute("aria-pressed",on);b.textContent=on?"❤️ Saved":"♡ Save"});
  if(here==="dashboard")dash();
 }
 else if(t.dataset.view){
  try{const{opportunity}=await api("/opportunities/"+t.dataset.view);show(detail(opportunity));streak()}catch(err){toast(err.message)}
 }
 else if(t.dataset.open==="post")postForm();
 else if(t.dataset.open==="sign")signIn();
 else if(t.dataset.info){const T={About:"Campusly is a student opportunity platform: a Flask API, a SQL Server database and a plain HTML/CSS/JavaScript frontend. The sample listings are fictional.",Contact:"No messages are sent from this site yet. Connect an email service to enable contact.",Privacy:"Your account details are stored in the Campusly database (passwords are hashed). Your sign-in token is kept in your browser.",Terms:"Sample terms: the seeded opportunities are fictional placeholders."};show(`<h2>${t.dataset.info}</h2><p>${T[t.dataset.info]}</p>`)}
 else if(t.hasAttribute("data-close"))dlg.close();
 else if(t.id==="sIcon"){const q=$("#q");q?(q.scrollIntoView({behavior:"smooth",block:"center"}),q.focus()):location.href="index.html"}
});
dlg.addEventListener("click",e=>{if(e.target===dlg)dlg.close()});

/* ---------- forms ---------- */
let refresh=()=>{};
const field=(id,l,type="text",req=1,extra="")=>`<label for="${id}">${l}</label><input id="${id}" name="${id}" type="${type}" ${req?"required":""} ${extra}>`;
const setBusy=(form,busy)=>{const b=$("button:not([type=button])",form);if(b)b.disabled=busy};
function postForm(){
 const today=new Date().toISOString().slice(0,10);
 show(`<h2>Post an opportunity</h2><p class="note">Your listing is saved to the Campusly database and appears on its category page.</p><form id="pf">${field("pt","Opportunity title","text",1,'maxlength="200"')}${field("po","Organization","text",1,'maxlength="160"')}<label for="pc">Category</label><select id="pc">${Object.keys(CATS).map(c=>`<option>${c}</option>`).join("")}</select><label for="pd">Description</label><textarea id="pd" required rows="3" maxlength="8000"></textarea>${field("pl","Location (write Online for remote)","text",1,'maxlength="160"')}${field("pdl","Deadline","date",1,`min="${today}"`)}${field("pe","Eligibility","text",0,'maxlength="300"')}${field("pu","Application URL (https://…)","url",0,'maxlength="300"')}${field("pm","Contact email","email",0,'maxlength="160"')}<p class="err" id="pfErr" role="alert"></p><button class="btn">Submit Opportunity</button></form>`);
 $("#pf").onsubmit=async e=>{e.preventDefault();const f=e.target;setBusy(f,true);$("#pfErr").textContent="";
  try{
   await api("/opportunities",{method:"POST",body:{category:$("#pc").value,title:$("#pt").value,organization:$("#po").value,location:$("#pl").value,deadline:$("#pdl").value,description:$("#pd").value,eligibility:$("#pe").value,url:$("#pu").value,contact_email:$("#pm").value}});
   $("#dlgBody").innerHTML=`<h2>✅ Opportunity submitted</h2><p>It's now live on its category page.</p><button class="btn" data-close>Done</button>`;refresh();
  }catch(err){$("#pfErr").textContent=err.message;setBusy(f,false)}};
}
function signIn(msg){
 if(USER){show(`<h2>Hi, ${esc(USER.name)}</h2><p class="note">${esc(USER.email)}</p><p><a href="dashboard.html">Go to my dashboard →</a></p><button class="btn" id="out">Sign out</button>`);
  $("#out").onclick=()=>{clearSession();location.reload()};return}
 show(`<h2>Welcome to Campusly</h2>${msg?`<p class="note">${esc(msg)}</p>`:""}<div class="tabs" role="group" aria-label="Account"><button type="button" class="tab" data-mode="login" aria-pressed="true">Log in</button><button type="button" class="tab" data-mode="signup" aria-pressed="false">Create account</button></div>
 <form id="af"><div id="nameWrap" hidden>${field("an","Your name","text",0,'autocomplete="name" maxlength="120"')}</div>${field("ae","Email","email",1,'autocomplete="email"')}${field("ap","Password (min 6 characters)","password",1,'autocomplete="current-password" minlength="6"')}
 <fieldset id="intWrap" hidden><legend>Your interests</legend>${INTERESTS.map((i,n)=>`<label class="chk"><input type="checkbox" value="${esc(i)}" ${n<3?"checked":""}> ${esc(i)}</label>`).join("")}</fieldset>
 <p class="err" id="afErr" role="alert"></p><button class="btn" id="afGo">Log in</button></form>`);
 let mode="login";
 $$(".tab").forEach(b=>b.onclick=()=>{mode=b.dataset.mode;$$(".tab").forEach(x=>x.setAttribute("aria-pressed",x===b));const su=mode==="signup";$("#nameWrap").hidden=$("#intWrap").hidden=!su;$("#an").required=su;$("#ap").autocomplete=su?"new-password":"current-password";$("#afGo").textContent=su?"Create account":"Log in";$("#afErr").textContent=""});
 $("#af").onsubmit=async e=>{e.preventDefault();const f=e.target;setBusy(f,true);$("#afErr").textContent="";
  const body={email:$("#ae").value,password:$("#ap").value};
  if(mode==="signup"){body.name=$("#an").value;body.interests=$$("#intWrap input:checked").map(x=>x.value)}
  try{const r=await api("/auth/"+mode,{method:"POST",body});TOKEN=r.token;USER=r.user;store.set("cs_token",TOKEN);store.set("cs_user",USER);location.reload()}
  catch(err){$("#afErr").textContent=err.message;setBusy(f,false)}};
 $("#ae").focus();
}

/* ---------- list: search + filters + sort ---------- */
async function initList(){
 const bar=$("#filters"),g=$("#grid");if(!bar)return;const cat=document.body.dataset.cat||"",home=here==="index";
 g.innerHTML='<div class="card sk"></div>'.repeat(3);
 let pool;try{pool=(await api("/opportunities"+(cat?"?category="+encodeURIComponent(cat):""))).opportunities}catch(err){gridError(g,err);return}
 const uniq=a=>[...new Set(a)].sort(),opt=a=>a.map(x=>`<option>${esc(x)}</option>`).join("");
 const sel=(id,l,o)=>`<label>${l}<select id="${id}"><option value="">All</option>${opt(o)}</select></label>`;
 bar.innerHTML=`<form class="filters" role="search"><div class="srow"><label class="sr" for="q">Search opportunities</label><input id="q" type="search" placeholder="What are you looking for?"><button class="btn">Search</button></div><div class="sels">${home?sel("fc","Category",Object.keys(CATS)):""}${sel("fl","Location",uniq(pool.map(o=>o.location)))}${sel("ft","Field / tag",uniq(pool.flatMap(o=>o.tags)))}${sel("fy","Online / In-person",["Online","In-person","Hybrid"])}<label>Deadline<select id="fd"><option value="">Any</option><option value="30">Next 30 days</option><option value="60">Next 60 days</option></select></label><label>Sort by<select id="fs"><option value="r">Recommended</option><option value="n">Newest</option><option value="d">Deadline Soon</option><option value="a">Recently Added</option></select></label></div></form>`;
 const v=id=>($("#"+id)||{}).value||"";let seq=0;
 const run=async()=>{
  const p=new URLSearchParams(),set=(k,x)=>x&&p.set(k,x);
  set("category",cat||v("fc"));set("location",v("fl"));set("tag",v("ft"));set("type",v("fy"));set("deadline_within",v("fd"));set("q",v("q").trim());set("sort",v("fs"));
  const mine=++seq;let r;
  try{r=await api("/opportunities?"+p)}catch(err){if(mine===seq)gridError(g,err);return}
  if(mine!==seq)return; // a newer search is already running
  let l=r.opportunities;
  const filtered=v("q").trim()||$$("select",bar).some(x=>x.id!=="fs"&&x.value);if(home&&!filtered)l=l.slice(0,6);
  grid(g,l);const c=$("#count");if(c)c.textContent=`${l.length} opportunit${l.length===1?"y":"ies"}`};
 refresh=run;
 let timer;bar.addEventListener("input",()=>{clearTimeout(timer);timer=setTimeout(run,250)});
 $("form",bar).onsubmit=e=>{e.preventDefault();run();g.scrollIntoView({behavior:"smooth"})};
 const q0=new URLSearchParams(location.search).get("q");if(q0)$("#q").value=q0;
 run();
}

/* ---------- streak, dashboard ---------- */
async function streak(){
 const els=$$(".streak");if(!els.length)return;let html;
 if(!USER)html="🔥 <b>Sign in to track the opportunities you explore.</b>";
 else{try{const n=(await api("/dashboard/streak")).opportunities_this_week;html=`🔥 <b>You've explored ${n} opportunit${n===1?"y":"ies"} this week.</b> Keep going!`}catch{return}}
 els.forEach(e=>e.innerHTML=html);
}
async function dash(){
 let d;try{d=await api("/dashboard")}catch(err){["savedGrid","deadGrid","recGrid"].forEach(id=>gridError($("#"+id),err));return}
 SAVED=new Set(d.saved.map(o=>o.id));
 grid($("#savedGrid"),d.saved,"Nothing saved yet. Tap ♡ Save on any card.");grid($("#deadGrid"),d.upcoming_deadlines);grid($("#recGrid"),d.recommended);
 $("#prog").style.width=d.profile_progress+"%";$("#progT").textContent=d.profile_progress+"%";
}
function initDash(){const b=$("#interests");if(!b)return;
 if(!USER){$(".dash").innerHTML=`<div><h2>Sign in to see your dashboard</h2><p>Your saved opportunities, upcoming deadlines and personal recommendations live here.</p><button class="btn" data-open="sign">Sign in or create an account</button></div>`;return}
 b.innerHTML=INTERESTS.map(i=>`<label class="chk"><input type="checkbox" value="${esc(i)}" ${(USER.interests||[]).includes(i)?"checked":""}> ${esc(i)}</label>`).join("");
 b.onchange=async()=>{try{const r=await api("/auth/interests",{method:"PUT",body:{interests:$$("input:checked",b).map(x=>x.value)}});USER=r.user;store.set("cs_user",USER);dash()}catch(err){toast(err.message)}};
 dash();
}

/* ---------- home category cards ---------- */
async function initCats(){
 const cg=$("#cats");if(!cg)return;
 try{const{categories}=await api("/categories");cg.innerHTML=categories.map(c=>`<a class="cat" href="${esc(c.slug)}.html"><span class="ci">${CATS[c.name]?.[0]||"⭐"}</span><b>${c.name==="MUN"?"MUNs":esc(c.name)+"s"}</b><small>${c.open} open</small></a>`).join("")}
 catch(err){cg.innerHTML=`<p class="empty">⚠️ ${esc(err.message)}</p>`}
}

/* ---------- start ---------- */
(async()=>{
 user();
 if(TOKEN){try{USER=(await api("/auth/me")).user;store.set("cs_user",USER)}catch{} await loadSaved();user()}
 initCats();initList();initDash();streak();
})();
const io=new IntersectionObserver(es=>es.forEach(x=>x.isIntersecting&&(x.target.classList.add("in"),io.unobserve(x.target))));$$(".reveal").forEach(e=>io.observe(e));
})();
